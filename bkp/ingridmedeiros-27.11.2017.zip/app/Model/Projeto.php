<?php
class Projeto extends AppModel {

    public $name = 'Projeto';

    public $validate = array(
       /* 'imagem'=> array(
            'rule' => 'notEmpty'
        )*/
    );
}